let pontuacao = 0;
let tempo = 0;
let bolinha = document.getElementById('bolinha');
let jogo = document.getElementById('jogo');
let apagar = document.getElementById('dificuldade');
let jogarNovamente = document.getElementById('jogaDnovo');


//Clamp

const min = 50
const max = 80

//Clamp number between two values with the following line:
const clamp = (num, min, max) => Math.min(Math.max(num, min), max)

//

let pontua =[
    {
        jogadores: "",
        senha:"",
        ptnfacil: 0,
        ptnmedio: 0,
        ptndificil: 0

    }
]; 



document.getElementById("facil").addEventListener('click', function() {
    pontuacao = 0;
    tempo = 10;
    iniciarJogo();
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';

   
});
document.getElementById("medio").addEventListener('click', function() {
    pontuacao = 0;
    tempo = 7;
    iniciarJogo();
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';
    
});
document.getElementById("dificil").addEventListener('click', function() {
    pontuacao = 0;
    tempo = 2;
    iniciarJogo();
    apagar.style.display = 'none';
    jogarNovamente.style.display = 'none';
    
});



function iniciarJogo() {
    pontuacao = 0;
    jogo.style.display = 'block'; 
    document.getElementById('pontuacao').innerText = `Pontuação: ${pontuacao}`;
    
    bolinha.addEventListener('click', () => {
        pontuacao++;
        document.getElementById('pontuacao').innerText = `Pontuação: ${pontuacao}`;
        bolinha.style.top = `${Math.floor((Math.random() * 50) + 25)}%`;
        //bolinha.style.bottom = `${Math.random() * 100}%`;
        bolinha.style.left = `${Math.floor((Math.random() * 50) + 25)}%`;
        //bolinha.style.right = `${Math.random() * 1}%`;
    
         
            if (pontuacao >= 10) {
                 bolinha.style.backgroundImage = 'url("sol.png")';
                 bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 20) {
                bolinha.style.backgroundImage = 'url("mercurio1.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 30) {
                bolinha.style.backgroundImage = 'url("venus.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 40) {
                bolinha.style.backgroundImage = 'url("terra.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 50) {
                bolinha.style.backgroundImage = 'url("marte.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 60) {
                bolinha.style.backgroundImage = 'url("jupiter.png")';
                bolinha.style.backgroundSize = 'contain';
                bolinha.style.borderImageWidth
            }
            if (pontuacao >= 70) {
                bolinha.style.backgroundImage = 'url("saturno.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 80) {
                bolinha.style.backgroundImage = 'url("urano.png")';
                bolinha.style.backgroundSize = 'contain';
            }
            if (pontuacao >= 90) {
                bolinha.style.backgroundImage = 'url("netuno.png")';
                bolinha.style.backgroundSize = 'contain';
            }

        });
    
    
    let intervalId = setInterval(() => {
        if (pontuacao > 0) {
            pontuacao--;
            document.getElementById('pontuacao').innerText = `Pontuação: ${pontuacao}`;
        } else {
            jogo.style.display = 'none'; 
            clearInterval(intervalId); 
            jogarNovamente.style.display = 'block';
        }
    }, tempo * 1000);
}

document.getElementById('volta').addEventListener('click', function novamente(){
    
    pontuacao = 0;
    jogo.style.display = 'none';
    apagar.style.display = 'block';
    jogarNovamente.style.display = 'none';

});
document.getElementById('voltar').addEventListener('click', function  (){

    jogo.style.display = 'none';
    apagar.style.display = 'block';
    alert('Sua pontuação é', `Pontuação: ${pontuacao}`);
    pontuacao = 0;
    

});